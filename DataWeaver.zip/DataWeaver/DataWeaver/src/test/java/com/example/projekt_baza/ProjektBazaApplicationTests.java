package com.example.projekt_baza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjektBazaApplicationTests {

	@Test
	void contextLoads() {
	}

}
