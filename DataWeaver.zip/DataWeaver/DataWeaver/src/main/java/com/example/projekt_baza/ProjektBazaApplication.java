package com.example.projekt_baza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektBazaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektBazaApplication.class, args);
	}

}
